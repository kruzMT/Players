﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Players
{
     class Player
    {
        public string name { get; set; }

        public Skills skls { get; set; }

        public Weight wg { get; set; }
    }

    
}
