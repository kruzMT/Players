﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Players
{
    public class Weight
    {
        public double Wspeed { get; set; }
        public double Wstamina { get; set; }
        public double Wtrenght { get; set; }
        public double Wmentality { get; set; }
        public double Wmomentum { get; set; }
        public double WrightH { get; set; }
        public double WleftH { get; set; }
        public double WnetG { get; set; }
        public double Wservice { get; set; }

        public double Wpitch { get; set; }

        public double Wtotal { get; set; }

        public double Wcomp { get; set; }
    }
}
